//
//  ContentView.swift
//  SCI.swift
//
//  Created by Phil Inglis on 2023-10-20.
//

import SwiftUI

let gameData = GameData()

struct ContentView: View {
    var body: some View {
        VStack {
            Button(action: {
                openGame()
            }, label: {
                Text("Open")
            })
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

private func openGame() {
    let dialog = NSOpenPanel()
    dialog.title = "Select Game Folder"
    dialog.showsResizeIndicator = true
    dialog.showsHiddenFiles = false
    dialog.allowsMultipleSelection = false
    dialog.canChooseDirectories = true
    dialog.canChooseFiles = false
    
    if (dialog.runModal() == NSApplication.ModalResponse.OK) {
        if let path = dialog.url?.path {
            print("Folder: \(path)")
            
            gameData.loadGameData(from: path,
                                  loadFinished: {
                print("Load finished")
            })
        }
    }
}

#Preview {
    ContentView()
}
