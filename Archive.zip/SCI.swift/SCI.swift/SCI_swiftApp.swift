//
//  SCI_swiftApp.swift
//  SCI.swift
//
//  Created by Phil Inglis on 2023-10-20.
//

import SwiftUI

@main
struct SCI_swiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
