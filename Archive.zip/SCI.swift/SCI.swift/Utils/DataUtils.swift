//
//  DataUtils.swift
//  SCI.swift
//
//  Created by Phil Inglis on 2023-10-20.
//

import Foundation

enum DataReadError: Error {
    case endOfData
}

struct DataUtils {
    
    static func getNextByte(at dataPosition: inout Int, from data: NSData) throws -> UInt8 {
        var byteBuffer: UInt8 = 0
        
        if dataPosition < data.length {
            data.getBytes(&byteBuffer, range: NSRange(location: dataPosition, length: 1))
            dataPosition += 1
            
            return byteBuffer
        }
        
        throw DataReadError.endOfData
    }
    
    static func getNextWord(at dataPosition: inout Int, from data: NSData) throws -> UInt16 {
        let low = try UInt16(getNextByte(at: &dataPosition, from: data))
        let high = try UInt16(getNextByte(at: &dataPosition, from: data))
        return UInt16((high << 8) + low)
    }
    
    static func getNextDoubleWord(at dataPosition: inout Int, from data: NSData) throws -> UInt32 {
        let one = try UInt32(getNextByte(at: &dataPosition, from: data))
        let two = try UInt32(getNextByte(at: &dataPosition, from: data))
        let three = try UInt32(getNextByte(at: &dataPosition, from: data))
        let four = try UInt32(getNextByte(at: &dataPosition, from: data))
        return UInt32(((four << 24) + (three << 16) + (two << 8) + one))
    }
    
    static func peekNextByte(at dataPosition: Int, from data: NSData) -> UInt8 {
        var byteBuffer: UInt8 = 0
        
        if dataPosition < data.length {
            data.getBytes(&byteBuffer, range: NSRange(location: dataPosition, length: 1))
            
            return byteBuffer
        }
        
        return 0
    }
    
    static func peekNextWord(at dataPosition: Int, from data: NSData) -> UInt16 {
        let low = UInt16(peekNextByte(at: dataPosition, from: data))
        let high = UInt16(peekNextByte(at: dataPosition + 1, from: data))
        return UInt16((high << 8) + low)
    }
    
    static func peekNextDoubleWord(at dataPosition: Int, from data: NSData) -> UInt32 {
        let one = UInt32(peekNextByte(at: dataPosition, from: data))
        let two = UInt32(peekNextByte(at: dataPosition + 1, from: data))
        let three = UInt32(peekNextByte(at: dataPosition + 2, from: data))
        let four = UInt32(peekNextByte(at: dataPosition + 3, from: data))
        return UInt32(((four << 24) + (three << 16) + (two << 8) + one))
    }
}
