//
//  GameData.swift
//  SCI.swift
//
//  Created by Phil Inglis on 2023-10-20.
//

import Foundation

enum ResourceType: UInt8 {
    case sprite
    case background
    case script
    case text
    case sound
    case memory
    case vocabulary
    case font
    case cursor
    case patch
}

struct ResourceMetaData: Hashable {
    let type: ResourceType
    let number: UInt16
    let fileNumber: UInt8
    let fileOffset: UInt32
}

protocol Resource {
    init(metaData: ResourceMetaData, data: Data)
}

struct Background: Resource {
    init(metaData: ResourceMetaData, data: Data) {
        
    }
}

struct GameData {
    
    enum GameDataFile: String {
        case resourceMap = "resource.map"
    }
    
    private var backgrounds: [Int: Background] = [:]
    
    // Load all game data from the provided folder
    mutating func loadGameData(from path: String, loadFinished: () -> Void) -> Bool {
        
        print("Resetting state")
        backgrounds.removeAll()
        
        print("Loading: \(path)")
        
        var resourceFilePaths = [String]()
   
        // Find all the numbered resource files (eg resource.001)
        do {
            let fileList = try FileManager.default.contentsOfDirectory(atPath: path)
            
            for file in fileList {
                if file.lowercased().starts(with: "resource."), !file.hasSuffix("map"), !file.hasSuffix("cfg") {
                    resourceFilePaths.append("\(path)/\(file)")
                }
            }
        } catch {
            print("Error loading game data: \(error)")
        }
        
        // Try and load the resource map, required for further operations, then load all resources
        let resourceMap = "\(path)/resource.map"
        
        guard FileManager.default.fileExists(atPath: resourceMap),
                loadResources(mapPath: resourceMap, resourcePaths: resourceFilePaths.sorted()) else {
            print("Failed to load resource.map")
            return false
        }
        
        loadFinished()
        return true
    }
    
    // Load the resource map, then using this load all the resources from the resource files
    internal func loadResources(mapPath: String, resourcePaths: [String]) -> Bool {
        
        // Load the file at the path as NSData
        if let data = NSData(contentsOfFile: mapPath) {
            print("Resource Map: \(mapPath), Data Size: \(data.count), Total Items: \((data.length / 6) - 1)")
            
            var backgroundMetaDatas = Set<ResourceMetaData>()
                        
            var dataPosition = 0
            
            // Pull the resource mappings from the resource.map file
            do {
                for _ in 0 ..< (data.length / 6) {
                    let resourceType: UInt16 = try DataUtils.getNextWord(at: &dataPosition, from: data)
                    let resourceFile: UInt32 = try DataUtils.getNextDoubleWord(at: &dataPosition, from: data)
                    
                    // FF FFFF means we are at the end
                    if resourceType == UInt16.max, resourceFile == UInt32.max {
                        print("Reached end of file")
                        print("Total Background Infos: \(backgroundMetaDatas.count)")
                        break
                    }
                    
                    // Resource Type - first 5 bits are type, last 11 bits are number
                    let rawType = UInt8(resourceType >> 11)
                    
                    // Unknown type - fail
                    guard let type = ResourceType(rawValue: rawType) else {
                        print("Unknown resource type: \(rawType)")
                        return false
                    }
                    
                    // Number used t identity the resource in logic
                    let number = UInt16(resourceType & 0x7FF)
                    
                    // Resource File - first 6 bits are file number, last 26 bits are file offset
                    let fileNumber = UInt8(resourceFile >> 26)
                    let fileOffset = UInt32(resourceFile & 0x3FFF7FF)
                    
                    let metaData = ResourceMetaData(type: type, number: number, fileNumber: fileNumber, fileOffset: fileOffset)
                    
                    switch type {
                        
                        // Background
                    case .background:
                        backgroundMetaDatas.insert(metaData)
                        
                        // Unknown
                    default:
                        print("Unknown type: \(type)")
                    }
                    
                    // In order to reduce disk swapping, the same resource may exist in multiple resource.xxx files, so store in
                    // a Set for each 'type' to avoid duplicates
                    // print("Resource: \(resource)")
                }
                
                var resourceFiles = [Int: Data]()
                
                // Now load the resources from the individual resource files based on the mappings
                for resourcePath in resourcePaths {
                    if let fileUrl = URL(string: resourcePath), let fileExtNum = Int(fileUrl.pathExtension) {
                        resourceFiles[fileExtNum] = try Data(contentsOf: fileUrl)
                    }
                }
                
                // Fetch all the pictures
                for metaData in backgroundMetaDatas {
                    
                    // Get the data header from the proper resource file
                    
                    // Fetch the compressed data
                    
                    // Decompress the data and create Background object
                    let background = Background(metaData: metaData, data: Data())
                }
                
            } catch {
                print("Error reading resource map: \(error)")
                return false
            }
        }
        
        return true
    }
}
