//
//  GameLoadingTests.swift
//  SCI.swiftTests
//
//  Created by Phil Inglis on 2023-10-20.
//

import XCTest
@testable import SCI_swift

final class GameLoadingTests: XCTestCase {
    
    func test_LoadResource() {
        
        let gameData = GameData()
        XCTAssertTrue(gameData.loadGameData(from: "/Users/phil.inglis/Personal/Sierra Games/SCI/sq3/", loadFinished: {}))
    }
}
